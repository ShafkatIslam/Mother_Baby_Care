<?php

define('HOST','localhost:3306');
define('USER','tikabarta_tikabarta');
define('PASS','*KZ;(E!qziwJ');
define('DB','tikabarta_baby_mother');

//to set up a connection
$con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');

?>
